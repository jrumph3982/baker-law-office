# Baker Law Office — WordPress Theme
## Installation & Setup Guide

### 1. Upload the Theme
1. Compress the `baker-law-office` folder into a `.zip` file.
2. In your WordPress admin, go to **Appearance → Themes → Add New → Upload Theme**.
3. Upload the zip and click **Activate**.

### 2. Upload the Attorney Photo
1. Go to **Media → Add New** and upload `jackie_baker.png`.
2. The About page template will use the **Featured Image** if set, or you can place the file at:  
   `wp-content/themes/baker-law-office/images/jackie_baker.png`

### 3. Create Pages & Assign Templates
Create the following pages in **Pages → Add New**:

| Page Title         | Slug                 | Page Template            |
|--------------------|----------------------|--------------------------|
| Home               | (front page)         | *(none — uses front-page.php)* |
| About              | `about`              | **About Page**           |
| Areas of Practice  | `areas-of-practice`  | **Areas of Practice**    |

### 4. Set the Front Page
1. Go to **Settings → Reading**.
2. Select **A static page** and choose **Home** as the Front page.

### 5. Set Up Navigation Menu *(optional)*
1. Go to **Appearance → Menus**.
2. Create a menu with: Home, Areas of Practice, About.
3. Assign to the **Primary Menu** location.
   *(The header currently uses hardcoded links tied to page slugs — this is optional.)*

### 6. Set Featured Image for About Page
1. Edit the **About** page.
2. In the right sidebar, set **Featured Image** to the uploaded `jackie_baker.png`.

---

### File Structure
```
baker-law-office/
├── style.css                       ← Theme declaration + all CSS
├── functions.php                   ← Enqueues, helpers, template registration
├── header.php                      ← <head> + <body> open
├── footer.php                      ← Calls baker_law_footer(), wp_footer()
├── index.php                       ← Fallback template (required by WP)
├── front-page.php                  ← Homepage (hero, welcome, practice cards, testimonials)
├── template-about.php              ← About Jackie Baker page
├── template-areas-of-practice.php ← Areas of Practice page
├── js/
│   └── main.js                     ← Hamburger, slider, scroll effects
└── images/
    └── jackie_baker.png            ← Upload here OR use WP Featured Image
```

---

### Notes
- The phone number **(269) 945-3999** appears in the header, footer, and CTA band. Update it in `functions.php` inside `baker_law_header()` and `baker_law_footer()`, or do a find-and-replace across all files.
- The hero background image pulls from Unsplash. To use a custom image, update the `background:` URL in `style.css` under `.hero-bg`.
- To add more testimonials, edit `front-page.php` and update the `totalSlides` count.
