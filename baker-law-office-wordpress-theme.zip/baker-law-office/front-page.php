<?php
/**
 * Baker Law Office — front-page.php (Home)
 * Set this as the static front page in Settings > Reading
 */
get_header();
baker_law_header('home');
?>

<!-- HERO -->
<section class="hero">
    <div class="hero-bg">
        <div class="hero-overlay"></div>
    </div>
    <div class="hero-content">
        <p class="hero-eyebrow">Trusted Legal Counsel</p>
        <h1 class="hero-title">Attorney<br><em>Jackie Baker</em></h1>
        <p class="hero-sub">There for you when you need it the most.</p>
        <div class="hero-ctas">
            <a href="tel:2699453999" class="btn btn-primary">Call Us</a>
            <a href="<?php echo esc_url( get_permalink( get_page_by_path('about') ) ); ?>" class="btn btn-outline">Learn More</a>
        </div>
    </div>
    <div class="hero-scroll-hint">
        <span>Scroll</span>
        <div class="scroll-line"></div>
    </div>
</section>

<!-- WELCOME -->
<section class="welcome section">
    <div class="container">
        <div class="section-rule"></div>
        <h2 class="section-title">Welcome To Baker Law Office, PLC</h2>
        <div class="section-rule"></div>
        <p class="welcome-text">
            Legal matters do not need to be confusing. With up-to-date knowledge and experience, Baker Law Office will ease
            you through legal issues without you feeling like just a number. Jackie attentively listens and tunes into your
            specific needs, providing the individual attention your issue deserves. Her straight-forward and
            easy-to-understand guidance on your case will ensure you do not feel lost in the world of legal jargon.
        </p>
    </div>
</section>

<!-- FAMILY LAW FOCUS -->
<section class="practice-areas section">
    <div class="container">
        <div class="section-rule"></div>
        <h2 class="section-title">A Focused Practice in Family Law</h2>
        <div class="section-rule"></div>
        <p class="welcome-text" style="margin-bottom: 3rem;">
            Jackie is now dedicating her practice exclusively to family law — the area where she has always been most
            passionate and effective. Families facing difficult legal challenges deserve an attorney who is fully invested,
            deeply knowledgeable, and genuinely committed to their outcome. That is exactly what Jackie brings to every case.
        </p>
        <div class="practice-grid">
            <div class="practice-card">
                <div class="practice-icon">👪</div>
                <span>Family Law</span>
            </div>
            <div class="practice-card">
                <div class="practice-icon">⚖</div>
                <span>Family Offense</span>
            </div>
            <div class="practice-card">
                <div class="practice-icon">🏠</div>
                <span>Custody</span>
            </div>
            <div class="practice-card">
                <div class="practice-icon">📅</div>
                <span>Visitation</span>
            </div>
            <div class="practice-card">
                <div class="practice-icon">💼</div>
                <span>Support Violations</span>
            </div>
        </div>
    </div>
</section>

<!-- TESTIMONIALS -->
<section class="testimonials section">
    <div class="container">
        <div class="testimonial-slider" id="testimonial-slider">
            <div class="testimonial-track" id="testimonial-track">
                <div class="testimonial-slide active" id="slide-0">
                    <blockquote>
                        Jackie has represented me for 5 years now. She has always gone up and above. Jackie has always taken the
                        time to listen to the issues and has come up with the best plan of action to succeed in court. She is very
                        knowledgeable and really cares about her clients. I would highly recommend her.
                    </blockquote>
                    <cite>— Elizabeth</cite>
                </div>
                <div class="testimonial-slide" id="slide-1">
                    <blockquote>
                        Jackie will assertively and aggressively pursue your case. She is a fantastic advocate, I would definitely recommend.
                    </blockquote>
                    <cite>— Michael</cite>
                </div>
                <div class="testimonial-slide" id="slide-2">
                    <blockquote>
                        Definitely went above and beyond for my family. She's amazing!
                    </blockquote>
                    <cite>— Tia</cite>
                </div>
            </div>
            <div class="testimonial-controls">
                <button class="t-prev" id="t-prev" aria-label="Previous">&#8592;</button>
                <div class="t-dots">
                    <span class="t-dot active" id="dot-0"></span>
                    <span class="t-dot" id="dot-1"></span>
                    <span class="t-dot" id="dot-2"></span>
                </div>
                <button class="t-next" id="t-next" aria-label="Next">&#8594;</button>
            </div>
        </div>
    </div>
</section>

<!-- CTA BAND -->
<section class="cta-band">
    <div class="container">
        <p>Sound legal advice is based on years of training, hard work, and passion, as well as familiarity with
        legislation and precedent and sound consideration. You'll find all that and more at Baker Law Office, PLC.</p>
    </div>
</section>

<?php get_footer(); ?>
