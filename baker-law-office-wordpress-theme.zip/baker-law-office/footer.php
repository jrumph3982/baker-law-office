<?php baker_law_footer(); ?>
<?php wp_footer(); ?>
</body>
</html>
