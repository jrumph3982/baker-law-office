<?php
/**
 * Baker Law Office — functions.php
 */

if ( ! defined( 'ABSPATH' ) ) exit;

/* ──────────────────────────────────────────
   THEME SETUP
────────────────────────────────────────── */
function baker_law_setup() {
    add_theme_support( 'title-tag' );
    add_theme_support( 'post-thumbnails' );
    add_theme_support( 'html5', [ 'search-form', 'comment-form', 'gallery', 'caption' ] );
    add_theme_support( 'customize-selective-refresh-widgets' );

    // Register nav menus
    register_nav_menus( [
        'primary' => __( 'Primary Menu', 'baker-law-office' ),
        'footer'  => __( 'Footer Menu', 'baker-law-office' ),
    ] );
}
add_action( 'after_setup_theme', 'baker_law_setup' );

/* ──────────────────────────────────────────
   ENQUEUE STYLES & SCRIPTS
────────────────────────────────────────── */
function baker_law_scripts() {
    // Google Fonts
    wp_enqueue_style(
        'baker-law-fonts',
        'https://fonts.googleapis.com/css2?family=Cormorant+Garamond:ital,wght@0,300;0,400;0,600;1,300;1,400&family=Jost:wght@300;400;500;600&display=swap',
        [],
        null
    );

    // Main stylesheet (style.css in theme root)
    wp_enqueue_style( 'baker-law-style', get_stylesheet_uri(), [ 'baker-law-fonts' ], '1.0.0' );

    // Main JS
    wp_enqueue_script(
        'baker-law-main',
        get_template_directory_uri() . '/js/main.js',
        [],
        '1.0.0',
        true // load in footer
    );
}
add_action( 'wp_enqueue_scripts', 'baker_law_scripts' );

/* ──────────────────────────────────────────
   WALKER: CLEAN NAV LINKS
────────────────────────────────────────── */
class Baker_Law_Nav_Walker extends Walker_Nav_Menu {
    function start_el( &$output, $item, $depth = 0, $args = null, $id = 0 ) {
        $classes  = empty( $item->classes ) ? [] : (array) $item->classes;
        $is_active = in_array( 'current-menu-item', $classes ) || in_array( 'current_page_item', $classes );
        $output .= sprintf(
            '<a href="%s"%s>%s</a>',
            esc_url( $item->url ),
            $is_active ? ' class="active"' : '',
            esc_html( $item->title )
        );
    }
}

/* ──────────────────────────────────────────
   HELPER: RENDER HEADER
────────────────────────────────────────── */
function baker_law_header( $active_page = '' ) {
    $pages = [
        'home'              => [ 'url' => home_url('/'),              'label' => 'Home' ],
        'areas-of-practice' => [ 'url' => get_permalink( get_page_by_path('areas-of-practice') ), 'label' => 'Areas of Practice' ],
        'about'             => [ 'url' => get_permalink( get_page_by_path('about') ),              'label' => 'About' ],
    ];
    ?>
    <header class="site-header">
        <div class="header-inner">
            <div class="header-logo">
                <a href="<?php echo esc_url( home_url('/') ); ?>">Baker Law Office, PLC</a>
            </div>
            <nav class="main-nav" id="main-nav">
                <?php foreach ( $pages as $key => $page ) : ?>
                    <a href="<?php echo esc_url( $page['url'] ); ?>"<?php echo ( $active_page === $key ) ? ' class="active"' : ''; ?>>
                        <?php echo esc_html( $page['label'] ); ?>
                    </a>
                <?php endforeach; ?>
            </nav>
            <a href="tel:2699453999" class="header-phone">
                <span class="phone-label">Call Us</span>
                <span class="phone-number">(269) 945-3999</span>
            </a>
            <button class="hamburger" id="hamburger" aria-label="Toggle menu">
                <span></span><span></span><span></span>
            </button>
        </div>
    </header>
    <?php
}

/* ──────────────────────────────────────────
   HELPER: RENDER FOOTER
────────────────────────────────────────── */
function baker_law_footer( $show_areas_link = true ) {
    ?>
    <section class="cta-band">
        <div class="container">
            <p>Sound legal advice is based on years of training, hard work, and passion. You'll find all that and more at
            Baker Law Office, PLC. <a href="tel:2699453999" style="color:var(--gold); text-decoration:none;">Call us today.</a></p>
        </div>
    </section>

    <footer class="site-footer">
        <div class="footer-inner container">
            <div class="footer-brand">
                <div class="footer-logo">Baker Law Office, PLC</div>
                <nav class="footer-nav">
                    <a href="<?php echo esc_url( home_url('/') ); ?>">Home</a>
                    <?php if ( $show_areas_link ) : ?>
                        <a href="<?php echo esc_url( get_permalink( get_page_by_path('areas-of-practice') ) ); ?>">Areas of Practice</a>
                    <?php endif; ?>
                    <a href="<?php echo esc_url( get_permalink( get_page_by_path('about') ) ); ?>">About</a>
                </nav>
            </div>
            <div class="footer-contact">
                <h4>Contact Information</h4>
                <address>43 Court Street, Suite 810<br>Buffalo, NY 14202</address>
                <a href="tel:2699453999" class="footer-phone" style="display:block;">(269) 945-3999</a>
                <a href="mailto:jackie@bakerlawplc.com" class="footer-phone" style="display:block;">jackie@bakerlawplc.com</a>
            </div>
        </div>
        <div class="footer-bottom container">
            <p>&copy; <?php echo date('Y'); ?> Baker Law Office, PLC. All Rights Reserved.</p>
        </div>
    </footer>
    <?php
}

/* ──────────────────────────────────────────
   REGISTER CUSTOM PAGE TEMPLATES
   (allows WP admin to assign templates)
────────────────────────────────────────── */
function baker_law_add_page_templates( $templates ) {
    $templates['template-home.php']              = 'Home Page';
    $templates['template-about.php']             = 'About Page';
    $templates['template-areas-of-practice.php'] = 'Areas of Practice';
    return $templates;
}
add_filter( 'theme_page_templates', 'baker_law_add_page_templates' );
