/* Baker Law Office — main.js (WordPress) */

document.addEventListener('DOMContentLoaded', function () {

    // ===== HAMBURGER MENU =====
    const hamburger = document.getElementById('hamburger');
    const mainNav   = document.getElementById('main-nav');

    if (hamburger && mainNav) {
        hamburger.addEventListener('click', () => {
            mainNav.classList.toggle('open');
            hamburger.classList.toggle('open');
        });
        mainNav.querySelectorAll('a').forEach(function(a) {
            a.addEventListener('click', () => {
                mainNav.classList.remove('open');
                hamburger.classList.remove('open');
            });
        });
    }

    // ===== TESTIMONIAL SLIDER =====
    const slides  = document.querySelectorAll('.testimonial-slide');
    const dots    = document.querySelectorAll('.t-dot');
    const prevBtn = document.getElementById('t-prev');
    const nextBtn = document.getElementById('t-next');

    if (slides.length > 0) {
        let current = 0;
        let autoTimer;

        function showSlide(n) {
            slides.forEach(function(s) { s.classList.remove('active'); });
            dots.forEach(function(d)  { d.classList.remove('active'); });
            current = ((n % slides.length) + slides.length) % slides.length;
            slides[current].classList.add('active');
            if (dots[current]) dots[current].classList.add('active');
        }

        function startAuto() {
            autoTimer = setInterval(function() { showSlide(current + 1); }, 5000);
        }

        function resetAuto() {
            clearInterval(autoTimer);
            startAuto();
        }

        showSlide(0);
        startAuto();

        if (prevBtn) {
            prevBtn.addEventListener('click', function() { showSlide(current - 1); resetAuto(); });
        }
        if (nextBtn) {
            nextBtn.addEventListener('click', function() { showSlide(current + 1); resetAuto(); });
        }

        dots.forEach(function(dot, i) {
            dot.addEventListener('click', function() { showSlide(i); resetAuto(); });
        });
    }

    // ===== SCROLL FADE-IN =====
    const fadeEls = document.querySelectorAll('.fade-up');
    if ('IntersectionObserver' in window && fadeEls.length > 0) {
        const observer = new IntersectionObserver(function(entries) {
            entries.forEach(function(entry) {
                if (entry.isIntersecting) {
                    entry.target.classList.add('visible');
                    observer.unobserve(entry.target);
                }
            });
        }, { threshold: 0.1 });
        fadeEls.forEach(function(el) { observer.observe(el); });
    }

    // ===== HEADER SCROLL EFFECT =====
    const header = document.querySelector('.site-header');
    if (header) {
        window.addEventListener('scroll', function() {
            header.style.background = window.scrollY > 60
                ? 'rgba(10, 18, 30, 0.98)'
                : 'rgba(15, 28, 46, 0.95)';
        }, { passive: true });
    }

    // ===== HASH HIGHLIGHT =====
    if (window.location.hash) {
        const target = document.querySelector(window.location.hash);
        if (target) {
            setTimeout(function() {
                target.style.background = 'rgba(200,169,110,0.06)';
                setTimeout(function() { target.style.background = ''; }, 1500);
            }, 300);
        }
    }

});
