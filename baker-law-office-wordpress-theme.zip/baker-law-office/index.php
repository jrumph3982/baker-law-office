<?php
/**
 * Baker Law Office — index.php (fallback)
 * WordPress requires this file. Primary content is in front-page.php and page templates.
 */
get_header();
baker_law_header();
?>

<section class="page-hero">
    <div class="page-hero-content">
        <p class="hero-eyebrow">Baker Law Office, PLC</p>
        <h1><?php the_title(); ?></h1>
    </div>
</section>

<section class="section">
    <div class="container">
        <?php if ( have_posts() ) : while ( have_posts() ) : the_post(); ?>
            <div class="about-text-col">
                <?php the_content(); ?>
            </div>
        <?php endwhile; endif; ?>
    </div>
</section>

<?php get_footer(); ?>
