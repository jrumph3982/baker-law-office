<?php
/**
 * Template Name: Areas of Practice
 * Baker Law Office — Legal Services
 */
get_header();
baker_law_header('areas-of-practice');
?>

<!-- PAGE HERO -->
<section class="page-hero">
    <div class="page-hero-content">
        <p class="hero-eyebrow">Legal Services</p>
        <h1>Areas of Practice</h1>
    </div>
</section>

<!-- PRACTICE DETAIL SECTIONS -->
<section class="practice-details section">
    <div class="container">

        <div class="practice-item" id="adoptions">
            <div class="practice-item-icon">⚖</div>
            <div class="practice-item-content">
                <h2>Adoptions</h2>
                <p>Bringing a new child into your family is one of life's greatest joys. Baker Law Office guides families
                through every step of the adoption process — from initial filings to finalizing the adoption in court —
                ensuring the experience is as smooth and joyful as possible.</p>
            </div>
        </div>

        <div class="practice-item" id="civil-suits">
            <div class="practice-item-icon">🏛</div>
            <div class="practice-item-content">
                <h2>Civil Suits</h2>
                <p>Whether you are pursuing or defending a civil claim, Jackie provides aggressive representation to protect
                your rights and interests. She handles disputes involving breach of contract, property damage, defamation,
                and other civil matters.</p>
            </div>
        </div>

        <div class="practice-item" id="contracts">
            <div class="practice-item-icon">📄</div>
            <div class="practice-item-content">
                <h2>Contracts</h2>
                <p>Contracts are the foundation of business and personal agreements. Baker Law Office assists with drafting,
                reviewing, and negotiating contracts to ensure your interests are protected and that agreements are clear,
                enforceable, and fair.</p>
            </div>
        </div>

        <div class="practice-item" id="divorce">
            <div class="practice-item-icon">⚖</div>
            <div class="practice-item-content">
                <h2>Divorce</h2>
                <p>Divorce is emotionally and legally complex. Jackie approaches every case with compassion and clarity,
                helping clients navigate asset division, spousal support, child custody, and parenting time while working
                toward a resolution that supports your future.</p>
            </div>
        </div>

        <div class="practice-item" id="estate-planning">
            <div class="practice-item-icon">🏠</div>
            <div class="practice-item-content">
                <h2>Estate Planning</h2>
                <p>Protect your assets and provide for your loved ones with a comprehensive estate plan. Baker Law Office
                assists with wills, trusts, powers of attorney, and advance directives tailored to your individual
                circumstances and goals.</p>
            </div>
        </div>

        <div class="practice-item" id="family-law">
            <div class="practice-item-icon">👪</div>
            <div class="practice-item-content">
                <h2>Family Law</h2>
                <p>Family legal issues are among the most personal you will ever face. Jackie handles custody disputes,
                parenting time modifications, child support, paternity, and other family matters with sensitivity and
                determination to achieve the best outcome for you and your children.</p>
            </div>
        </div>

        <div class="practice-item" id="landlord-tenant">
            <div class="practice-item-icon">🔑</div>
            <div class="practice-item-content">
                <h2>Landlord / Tenant</h2>
                <p>Whether you are a landlord seeking to enforce lease terms or a tenant facing wrongful eviction, Baker Law
                Office provides experienced guidance on landlord-tenant law, lease disputes, security deposits, and
                eviction proceedings.</p>
            </div>
        </div>

        <div class="practice-item" id="probate">
            <div class="practice-item-icon">📋</div>
            <div class="practice-item-content">
                <h2>Probate / Estate</h2>
                <p>Navigating probate after the loss of a loved one can be overwhelming. Jackie assists executors,
                administrators, and beneficiaries through the probate process, ensuring estates are administered efficiently
                and in accordance with applicable law.</p>
            </div>
        </div>

        <div class="practice-item" id="neglect-abuse">
            <div class="practice-item-icon">🛡</div>
            <div class="practice-item-content">
                <h2>Neglect / Abuse Proceedings</h2>
                <p>Baker Law Office represents families and individuals in Child Protective Services proceedings, advocating
                for the safety and best interests of children while protecting the rights of parents and guardians
                throughout the process.</p>
            </div>
        </div>

        <div class="practice-item" id="injury">
            <div class="practice-item-icon">⚕</div>
            <div class="practice-item-content">
                <h2>Personal Injury</h2>
                <p>If you have been injured due to the negligence of another, you deserve fair compensation. Jackie fights on
                behalf of injured clients in auto accidents, slip and fall cases, and other personal injury matters to help
                you recover what you are owed.</p>
            </div>
        </div>

    </div>
</section>

<!-- CTA -->
<section class="cta-band">
    <div class="container">
        <p>Ready to discuss your legal matter? Call us today at <a href="tel:2699453999"
            style="color:var(--gold); text-decoration:none;">(269) 945-3999</a> for a consultation.</p>
    </div>
</section>

<?php get_footer(); ?>
