<?php
/**
 * Template Name: About Page
 * Baker Law Office — About Jackie Baker
 */
get_header();
baker_law_header('about');
?>

<section class="page-hero">
    <div class="page-hero-content">
        <p class="hero-eyebrow">Meet Your Attorney</p>
        <h1>About Jackie Baker</h1>
    </div>
</section>

<section class="about-section section">
    <div class="container about-grid">
        <div class="about-image-col">
            <?php
            // Use featured image if set, otherwise fall back to uploaded photo
            if ( has_post_thumbnail() ) {
                the_post_thumbnail( 'full', [ 'style' => 'width:100%;height:100%;object-fit:cover;display:block;', 'alt' => 'Attorney Jackie Baker' ] );
            } else {
                echo '<img src="' . esc_url( get_template_directory_uri() . '/images/jackie_baker.png' ) . '" alt="Attorney Jackie Baker" style="width:100%;height:100%;object-fit:cover;display:block;" />';
            }
            ?>
        </div>
        <div class="about-text-col">
            <div class="section-rule"></div>
            <h2 class="section-title">Attorney Jackie Baker</h2>
            <div class="section-rule"></div>
            <p>Jackie grew up just outside of Buffalo, New York, a community that shaped her values, resilience, and belief
                that legal representation should be both strong and personal. After building her legal career in Michigan for
                more than 13 years, she has returned home to Buffalo with the experience, perspective, and courtroom
                confidence that only years of hands-on advocacy can provide.</p>
            <p>Jackie began practicing law while still in law school, selected for the Access to Justice legal clinic where
                she represented clients under the supervision of licensed attorneys. That early trial experience gave her more
                than academic knowledge. It gave her practical courtroom skill and a deep understanding of how legal outcomes
                affect real families. That foundation continues to define her approach today.</p>
            <p>Over the course of her career, Jackie has handled a wide range of legal matters including adoptions, civil
                litigation, contracts, divorce, estate planning, landlord and tenant disputes, probate proceedings, neglect
                and abuse cases, and personal injury claims. This breadth of experience gives her a well rounded perspective
                and the ability to recognize how different areas of law often intersect.</p>
            <p>Today, Jackie is focusing her practice on family law, particularly Family Offenses, Custody, Visitation, and
                Support Violations. She understands that family related matters are often the most personal and emotionally
                complex legal challenges a person can face. Her approach is steady, strategic, and client centered, advocating
                firmly while remaining attentive to the long term well being of the families she represents.</p>
            <p>Now back in Buffalo, Jackie brings seasoned courtroom experience, practical judgment, and a commitment to
                individualized advocacy to every case. She looks forward to guiding you through your legal needs with clarity,
                strength, and compassion.</p>
        </div>
    </div>
</section>

<!-- OFFICE -->
<section class="offices-section section">
    <div class="container">
        <div class="section-rule"></div>
        <h2 class="section-title">Our Office</h2>
        <div class="section-rule"></div>
        <div class="offices-grid" style="grid-template-columns: 1fr; max-width: 480px; margin: 3rem auto 0;">
            <div class="office-card">
                <h3>Buffalo, NY</h3>
                <address>43 Court Street, Suite 810<br>Buffalo, NY 14202</address>
                <a href="tel:2699453999">(269) 945-3999</a>
            </div>
        </div>
    </div>
</section>

<?php get_footer(); ?>
